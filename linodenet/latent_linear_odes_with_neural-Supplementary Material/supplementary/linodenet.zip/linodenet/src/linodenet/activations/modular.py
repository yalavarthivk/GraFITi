r"""Implementations of activation functions.

Notes
-----
Contains activations in modular form.
  - See `linodenet.models.activations.functional` for functional implementations.
"""
