r"""Tests regarding projection components."""
