r"""Tests for the LinODE-Net package.

This is only here to make ``pylint test`` possible.
The test folder should be ignored in setup.py anyway.
"""
