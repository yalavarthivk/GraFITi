#!/usr/bin/env bash
# Installs pre-commit hooks

pre-commit install
