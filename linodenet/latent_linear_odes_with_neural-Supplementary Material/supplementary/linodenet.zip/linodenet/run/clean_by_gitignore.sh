#!/usr/bin/env bash
git rm -r --cached .
git add .
git status
