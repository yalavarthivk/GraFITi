LinODEnet - 𝗟𝗶𝗻ear 𝗢rdinary 𝗗ifferential 𝗘quation 𝗡𝗲𝘁work
===========================================================

.. image:: ../diagram/linodenet-sketch.svg
   :width: 50%
   :alt: LinODEnet-sketch

Installation
============

First create a virtual environment, note that poetry might be currently broken.

.. code:: bash

  python -m venv .venv
  .venv/bin/activate
  poetry install
